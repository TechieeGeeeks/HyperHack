import React from "react";
import HeroComp from "../comp/HeroComp";

const Homepage = () => {
  return (
    <div>
      <HeroComp />
    </div>
  );
};

export default Homepage;
