import React from 'react'

const LiquidateNFT = () => {
  return (
    <div>LiquidateNFT</div>
  )
}

export default LiquidateNFT