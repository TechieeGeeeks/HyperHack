import NFT1 from "../img/nft1.webp";

const nftData = [
  {
    title: "NFT Title 1",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 2",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 3",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 4",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 5",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 6",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 7",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 8",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 9",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
  {
    title: "NFT Title 10",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit.Consequuntur, fuga assumenda amet saepe, repellendus omnis accusamus quia nostrum tenetur autem ullam nam. Repudiandae aperiam excepturi magni maiores nobis modi.",
    imageSrc: NFT1,
  },
];

export default nftData;
