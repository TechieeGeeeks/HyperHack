import React, { useState, useEffect } from "react";
import { AiFillCloseCircle } from "react-icons/ai";
import { Alchemy, Network } from 'alchemy-sdk';
import { Link } from "react-router-dom";

const TakeLoan = ({ signer, provider, account, tokenId, setTokenId, nftContractABI, nftContractAddress }) => {
  const [userNFTs, setUserNFTs] = useState([]);
  const [selectedNft, setSelectedNft] = useState(null);
  const [tokenDataObjects, setTokenDataObjects] = useState([]);
  const [hasQueried, setHasQueried] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!hasQueried) {
      getNFTsForOwnerAddress();
    }
  }, []); // Empty dependency array means this effect runs once when the component mounts

  async function getNFTsForOwnerAddress() {
    setIsLoading(true);
    setError(null);

    try {
      const config = {
        apiKey: 'hnbRprBMKeAwm0lSGsf2PpUM8WzUqK0i',
        network: Network.ETH_SEPOLIA,
      };

      const alchemy = new Alchemy(config);
      const data = await alchemy.nft.getNftsForOwner(account);
      setUserNFTs(data);

      const tokenDataPromises = [];

      for (let i = 0; i < data.ownedNfts.length; i++) {
        const tokenData = alchemy.nft.getNftMetadata(
          data.ownedNfts[i].contract.address,
          data.ownedNfts[i].tokenId
        );
        tokenDataPromises.push(tokenData);
      }

      const tokenDataResults = await Promise.all(tokenDataPromises);
      setTokenDataObjects(tokenDataResults);
      setHasQueried(true);
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  }

  // Function to open the NFT pop-up
  const openPopup = (nft) => {
    setSelectedNft(nft);
    setTokenId(nft.tokenId);
  };

  // Function to close the NFT pop-up
  const closePopup = () => {
    setSelectedNft(null);
  };

  return (
    <div>
      {isLoading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}

      <p className="text-[2rem] md:text-[3rem] md:mt-10 font-semibold mb-4 md:mb-8">
        Available NFTs
      </p>
      <div className="grid md:grid-cols-3 lg:grid-cols-4 grid-cols-1 mt-5 md:mt-0 gap-10">
        {tokenDataObjects.map((nft, index) => (
          <div className="bg-cardBg flex flex-col rounded-lg pb-4" key={index}>
            <img
              src={nft.rawMetadata.image}
              alt={nft.title}
              className="rounded-lg"
              style={{ height: '300px' }} // Set the desired height here
            />
            <div className="p-4">
              <p className="font-semibold text-xl">{nft.title}</p>
              <p className="text-subtitleColor text-justify mt-3">
                {nft.description}
              </p>
              <button
                className="bg-primaryColor text-backgroundColor font-semibold py-3 rounded-xl mt-6 w-full"
                onClick={() => openPopup(nft)}
              >
                Take Loan
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Pop-up/Modal */}
      {selectedNft && (
        <div className="fixed h-screen inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white md:p-8 p-4 rounded-lg m-8 md:m-0 md:w-1/2">
            <div className="flex items-end justify-end">
              <AiFillCloseCircle
                className="text-xl mb-4 md:text-3xl md:mb-6 text-gray-600 cursor-pointer"
                onClick={closePopup}
              />
            </div>
            <div className="flex items-center justify-center flex-col">
              <img
                src={selectedNft.rawMetadata.image}
                alt={selectedNft.title}
                className="rounded-lg"
                style={{ height: '300px' }} // Set the desired height here
              />
              <p className="font-semibold text-lg text-backgroundColor mt-3">
                {selectedNft.title}
              </p>
              <p className="text-subtitleColor text-justify mt-3">
                {selectedNft.description}
              </p>
              <Link to="/loanProcess">
                <button className="text-backgroundColor font-semibold bg-primaryColor w-full rounded-lg py-3 mt-5">
                  Start the Process 🔃
                </button>
              </Link>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TakeLoan;
