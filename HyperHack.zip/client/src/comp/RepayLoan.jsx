import React from 'react'

const RepayLoan = () => {
  return (
    <div>RepayLoan</div>
  )
}

export default RepayLoan