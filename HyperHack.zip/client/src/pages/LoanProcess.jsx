import React from 'react'
import { useEffect } from 'react'

const LoanProcess = ({ tokenId, nftContract }) => {
  useEffect(() => {
    console.log(nftContract);
  }, [])

  const giveApproval = async()=>{
    await nftContract.approve("0xc116C9053d7810d19843fEcc15307dA4DEaC776b",0);
  }
  
  return (
    <div>
      <div>
      <button
                className="bg-primaryColor text-backgroundColor font-semibold py-3 rounded-xl mt-6 w-full"
                onClick={() => giveApproval()}
              >
                Give Approval
              </button>

      </div>
    </div>
  )
}

export default LoanProcess